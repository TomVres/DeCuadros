import { useState, useContext, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../../context/CartContext';
import { CartItem } from '../CartItem/CartItem.jsx'

export const Cart = () => {
  const cartContext = useContext(CartContext);
  const [cartQty, setCartQty] = useState(0);

  const handleRemove = (itemId) => { cartContext.removeItem(itemId) };

  useEffect(() => {
    setCartQty(cartContext.getTotalQty())
  }, [cartContext.cart])

  return (
    <div className="container p-5">
      {
        !!cartQty
          ? <div>
            <ul className="shopping-cart-items">
              {
                cartContext.cart.map(
                  ({ item, quantity }) => <CartItem item={item} quantity={quantity} remove={() => handleRemove(item.id)} key={item.id} />
                )
              }
            </ul>
            <p >
              TOTAL: {cartContext.getTotalPrice()}
            </p>
            <Link className="button" to="/checkout">Checkout</Link>
          </div>
          : <div className="p-5">
            <h2>Carrito vacio</h2>
            <Link className="button text-light" to="/">Ir a comprar</Link>
          </div>
      }
    </div>
  )
}