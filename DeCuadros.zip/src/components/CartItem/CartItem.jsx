export const CartItem = ({ item, quantity, remove }) => {
  return (
    <li className="d-flex justify-content-between p-2">
      <img src={item.pictureUrl} alt="item1" style={{ width: '5rem' }} />
      <div className="p-2" >
        <h4 className="item-name">{item.title}</h4>
        <span className="item-price">$ {item.price} </span>
        <span className="item-quantity">Cant: {quantity} </span>
      </div>
      <button type="button" className="btn btn-warning" onClick={remove}><i className="far fa-trash-alt"></i></button>
    </li>
  )
}