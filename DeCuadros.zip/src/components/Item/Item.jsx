import "./style.css"
import { ItemCount } from '../ItemCount/ItemCount.jsx'
import { Link } from 'react-router-dom'

export const Item = ({ item }) => {

  return (
    <div className="col-md-4 mb-4">
      <div className="card">
        <img src={item.pictureUrl} className="card-img-top" alt={item.title} />
        <div className="card-body">
          <h5 className="card-title">{item.title}</h5>
          <p className="card-text stock-text">Stock disponible: {item.stock}</p>
          <p className="card-text price-text">${item.price}</p>
          <Link to={"/item/" + item.id}>Ver Detalle</Link>
        </div>
      </div>
    </div>
  )

}
