import { getFirestore } from "../firebase/firestore";

export async function getItems() {
    const DB = getFirestore(); //Conexión con DB
    const COLLECTION = DB.collection("items"); //Conexión con la collection
    const data = await COLLECTION.get();
    let items = data.docs.map((doc) => { return { ...doc.data(), id: doc.id } });
    return items;
}

export async function getCategories() {
    const DB = getFirestore(); //Conexión con DB
    const COLLECTION = DB.collection("categories"); //Conexión con la collection
    const data = await COLLECTION.get();
    let categories = data.docs.map((doc) => doc.data().Name);
    return categories;
}

export async function getItemDetail(id) {
    const products = await getProducts();
    const product = products.find(element => element.id == id);
    return product;
}

export async function getItemsByCategory(category) {
    const products = await getProducts();
    const filteredProducts = products.filter(element => element.category == category);
    return filteredProducts;
}