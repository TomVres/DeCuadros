import firebase from "firebase/app";
import "@firebase/firestore";

const firebaseConfig = firebase.initializeApp ({
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
});

export const getFirebase = () => {
  return firebaseConfig
}

export const getFirestore = () => {
  return firebase.firestore(firebaseConfig);
}

