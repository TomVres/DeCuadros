import { useEffect, useState } from "react";
import "./style.css"
import { ItemList } from '../../components/ItemList/ItemList';
import { getItems, getItemsByCategory } from "../../database/api-json";
import { useParams } from "react-router-dom";

export function ItemListContainer() {
  const [items, setItems] = useState([]);
  let { id } = useParams();

  useEffect(() => {
    const waitForData = async () => {
      let _items;
      if (id) {
        _items = await getItemsByCategory(id)
      } else {
        _items = await getItems();
      }

      setItems(_items);
    }

    waitForData()

  }, [id])

  return (
    <div className="row pt-5 p-5">
      {
        !!items
          ? <ItemList items={items} />
          : 'Loading...'
      }
    </div>
  );
}


