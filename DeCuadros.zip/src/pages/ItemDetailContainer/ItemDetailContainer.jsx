import { useEffect, useState } from "react";
import { useParams } from 'react-router-dom';
import "./style.css"
import { ItemDetail } from '../../components/ItemDetail/ItemDetail';
import { getItemDetail } from "../../database/api-json";
export function ItemDetailContainer() {
  let [item, setItem] = useState({});
  let { id } = useParams();

  useEffect(() => {
    const waitForData = async () => {
      let _item = await getItemDetail(id);
      setItem(_item);
    }
    waitForData();
  }, [])

  return (
    <div className="row">
      <ItemDetail item={item} />
    </div>
  );
}

