import { Cart } from '../../components/Cart/Cart'

export function CartContainer() {

    return (
        <Cart />
    )
}